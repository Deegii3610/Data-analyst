import patient_data as p

def get_patient(id):
    return p.patients[id]["name"], p.patients[id]["age"], p.patients[id]["gender"]
#Takes a patient ID and returns the patients name, age and gender.



def get_diagnosis(id):
    return p.patients[id]["diagnosis"]
#Takes a patient ID and returns the patients diagnosis.


def get_medications(id):
    return p.patients[id]["medications"]
#Takes a patient ID and returns the patients medications.


def get_allergies(id):
    return p.patients[id]["allergies"]
#Takes a patient ID and returns the patients allergies.


def get_meet_dates(id):
    return p.patients[id]["last_checkup_date"], p.patients[id]["next_appointment_date"]
#Takes a patient ID and returns the last_checkup_date and next_appointment_date.


def get_ids():
    return p.patients.keys()
#Returns a list of patient IDs.

