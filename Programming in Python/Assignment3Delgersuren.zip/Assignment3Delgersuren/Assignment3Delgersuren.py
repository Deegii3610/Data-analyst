import patient_data as p
import fetch_patient_data as fe
import pandas as pd
from datetime import datetime

#Part 1.1/3 average age
def average_age(ages):
    try:
        a = ages.mean()
        return a
    except:
        ages_numeric = pd.to_numeric(ages)  
        a = ages_numeric.mean()
        return a
    

#Part 1.2/3 appends the specified medication
def add_medication(id, med):
    try:
        return p.patients[id]["medications"].append(med)
    except:
        p.patients[id]["medications"] = list(p.patients[id]["medications"])
        return p.patients[id]["medications"].append(med)

#Part 1.3/3 e time difference
def upcoming_appointments(id):
    date1 = datetime.strptime(p.patients[id]['last_checkup_date'], '%Y-%m-%d')
    date2 = datetime.strptime(p.patients[id]['next_appointment_date'],'%Y-%m-%d')
    time_difference = date2-date1
    return time_difference


# Part 1
patient_list = [{'PatientID': PatientId, **data} for PatientId, data in p.patients.items()]
df = pd.DataFrame(patient_list)
averageAge = average_age(df["age"])
print("Part 1")
print(f"Average age of all patients: {averageAge} \n")

# Part 2 
meds = ["Aspirin", "Acetaminophen", "Penicillin", "Amoxicillin", "Ibuprofen", "Hydrochlorothiazide"]
print("Part 2\n")
for id, med in zip(p.patients.keys(),meds):
    print("Medications before: ", p.patients[id]["medications"])
    add_medication(id, med)
    print("Medications after: ", p.patients[id]["medications"])

# Part 3
ID = "P12345"
print("\nPart 3")
print(f"PaitentID {ID} time difference {upcoming_appointments(ID)}")

