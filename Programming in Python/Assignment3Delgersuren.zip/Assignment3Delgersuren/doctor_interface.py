import fetch_patient_data as fe

print(fe.get_ids())

print("Options:     details, diagnosis, allergies, dates")




a = 1 

while a:
    ID = input("Enter the user ID: " )
    
    if ID in fe.get_ids():
        keyo = input("Enter option from the above options: ")
        if keyo == "details":
            print(fe.get_patient(ID))
            a=0
        elif keyo == "diagnosis":
            print(fe.get_diagnosis(ID))
            a=0
        elif keyo == "allergies":
            print(fe.get_allergies(ID))
            a=0
        elif keyo == "allergies":
            print(fe.get_allergies(ID))
            a=0
        elif keyo == "dates":
            print(fe.get_meet_dates(ID))
            a=0
        else: 
            print("Please enter correct option")
            a=1
    else: 
        print("Please enter correct ID")
        a=1


